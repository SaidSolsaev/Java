
public class Main {
    public static void main(String[] args) {
        //new Velkommen();
        StartSpill spill = new StartSpill();
        spill.start();
    }
}
